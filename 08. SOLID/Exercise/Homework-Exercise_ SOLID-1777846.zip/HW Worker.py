from abc import ABC, abstractmethod


class Worker(ABC):
    @staticmethod
    @abstractmethod
    def work():
        pass


class NormalWorker(Worker):

    @staticmethod
    def work():
        print("I work!!!")

class SuperWorker(Worker):

    @staticmethod
    def work():
        print("I work very hard!!!")

class Manager:

    def __init__(self):
        self.worker = None

    def set_worker(self, worker):
        self.worker = worker

        if not isinstance(worker, Worker):
            raise AssertionError(f"`worker` must be of type {Worker}")

    def manage(self):
        if self.worker is not None:
            self.worker.work()

