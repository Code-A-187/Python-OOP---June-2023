from abc import ABCMeta, abstractmethod
import time


class AbstractWorker:
    __metaclass__ = ABCMeta

    @abstractmethod
    def work(self):
        pass


class Eating:
    __metaclass__ = ABCMeta

    @abstractmethod
    def eat(self):
        pass


class Worker(AbstractWorker, Eating):

    def work(self):
        print("I'm normal worker. I'm working.")

    def eat(self):
        print("Lunch break....(5 secs)")
        time.sleep(5)


class SuperWorker(AbstractWorker,Eating):

    def work(self):
        print("I'm super worker. I work very hard!")

    def eat(self):
        print("Lunch break....(3 secs)")
        time.sleep(3)


class Robot(AbstractWorker):

    def work(self):
        print("I'm a robot. I'm working....")




class WorkManager:

    def __init__(self):
        self.worker = None

    def set_worker(self, worker):
        assert isinstance(worker, AbstractWorker), f"`worker` must be of type {AbstractWorker}"

        self.worker = worker

    def manage(self):
        self.worker.work()


class BreakManager:

    def __init__(self):
        self.worker = None

    def set_worker(self, worker):
        if not isinstance(worker, Eating):
            raise AssertionError(f"`worker` must be of type {Eating}")

        self.worker = worker

    def lunch_break(self):
        self.worker.eat()

w_manager = WorkManager()
b_manager = BreakManager()


w_manager.set_worker(Worker())
w_manager.manage()


b_manager.set_worker(Worker())
b_manager.lunch_break()

w_manager.set_worker(SuperWorker())
w_manager.manage()


b_manager.set_worker(SuperWorker())
b_manager.lunch_break()

w_manager.set_worker(Robot())
w_manager.manage()


b_manager.set_worker(Robot())
b_manager.lunch_break()

